#!/usr/bin/env bash
set -euo pipefail

REGION="ap-south-1"
TAG_KEY="Environment"
TAG_VALUE="Dev"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --region) REGION="$2"; shift 2 ;;
    --tag) IFS='=' read -r TAG_KEY TAG_VALUE <<< "$2"; shift 2 ;;
    --help)
      echo "Usage: $0 [--region REGION] [--tag KEY=VALUE]"
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done

QUERY="Reservations[].Instances[?Tags[?Key=='${TAG_KEY}' && Value=='${TAG_VALUE}']].{ID:InstanceId,Type:InstanceType,State:State.Name,AZ:Placement.AvailabilityZone}"

aws ec2 describe-instances   --region "$REGION"   --query "$QUERY"   --output table
